"""
This is a concept idea for a snake game by Remington Martinez (rmm2gq) and Burhan Chaudhry (bmc8kh):

*The user will be required to use the basic motion controls of WASD or arrow pads to be able to move their snake character, snake will have a design implication of some form.

*Beginning window will show the basic information requirement along with choosing between single/multiplayer mode (start off with basic information, scroll down to read instructions, scroll further down to see credits. 

*As the time progresses, the user will be made to collect the snake food and by grabbing food the image file used for the snake will become elongated until either the person collides with themselves or they hit a wall.

*There will be an ability to have a choice between single player/multiplayer.

    If single player is chosen then it will follow the game mode until person collides with themselves. 

    While if multiplayer is chosen, the game will allow for the WASD and arrow pads to be used to control both snakes where the object of the game is to neither collide with the opponent, self, or walls. 

*Time elapsed through game-play will be displayed, while in multi-payer mode, there will be the added feature of player win rate for each side (which will erase upon script closing).
*Snake animation to resemble a slithering worm of some sorts (hitting the slithering snake will not cause death to player/if possible, image overlap will be resolved if it occurs to begin with [possible adding further boundaries to separate the squares the snake can run]).
#Snake animation may not be done, instead, making various gui's like pausing, and info gui's to access other sections may be better for the user along with animation for the loading screen (tbd)
*Also, the snake will move in the desired direction of the person’s control movement, until collision or direction change (will only turn right on set paths [e.g. not allowing user to move diagonally])

1st iteration:
import pygame
import gamebox
import random
pygame.init()
camera = gamebox.Camera(800, 600)
snake = gamebox.from_color(50, 310, "white", 10, 30)
score = 0
points =[gamebox.from_color(300, 310, "green", 10, 10), gamebox.from_color(700, 310, "green", 10, 10)]
game_on = False


def tick(keys):
    global snake, points
    camera.clear("black")
    if pygame.K_w in keys:
        snake.rotate(90)
        snake.move(0, -5)
    if pygame.K_s in keys:
        snake.rotate(90)
        snake.move(0, 5)
    if pygame.K_a in keys:
        snake.rotate(90)
        snake.move(-5, 0)
    if pygame.K_d in keys:
        snake.rotate(90)
        snake.move(5, 0)


    camera.draw(snake)
    camera.display()


ticks_per_second = 30
gamebox.timer_loop(ticks_per_second, tick)

import pygame, time, random

"""

"""
Manners in which the game satisfies the project's main function:

Main Features:
1) User Input (WASD to move around)
2) Graphics/Images (Snake)
3) Start Screen (Info page has computing ID's and instructions)
4) Sized down to (800,600) window size

Optional Feautures:
1) Snake Animation
2) Collectables (bomb)
3) Different levels
4) Something More- Smooth user interface for the game
"""
import pygame, time, random, gamebox

pygame.init() 



display_width = 800;
display_height = 600
black = (0,0,0)
dull_white = (250,235,215)
white = (255,255,255)
red = (220, 0, 0)
bright_red = (255,0,0)
green = (0,200,0)
bright_green = (0,255,0)
gameDisplay = pygame.display.set_mode((display_width, display_height))
clock = pygame.time.Clock()

def easy_mode():
    global level
    level = "easy"
    begin_game()

def hard_mode():
    global level
    level = "hard"
    begin_game()

def begin_game():

    def play_game(head, body, bomb_position, direction, bomb, hit):
        global dead
        dead = False
        prev_direction = 1

        while not dead:
            for event in pygame.event.get():

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a and prev_direction != 1:
                        direction = 0
                    elif event.key == pygame.K_d and prev_direction != 0:
                        direction = 1
                    elif event.key == pygame.K_w and prev_direction != 2:
                        direction = 3
                    elif event.key == pygame.K_s and prev_direction != 3:
                        direction = 2
                    elif event.key == pygame.K_ESCAPE:
                        global pause
                        pause = True
                        paused()
            
            cool = [(100,100,100),(101,101,101),(102,102,102)]
            colorz = cool[(random.randrange(len(cool)))]
            display.fill(colorz)
            display.blit(bomb,(bomb_position[0], bomb_position[1]))
            font = pygame.font.SysFont('Comic Sans MS', 30)
            text_surface = font.render(('Score:' + str(hit)), True, (0, 0, 0))
            display.blit(text_surface, dest=(0,0))
            for position in body:
                pygame.draw.rect(display,color[(random.randrange(len(color)))],pygame.Rect(position[0],position[1],10,10))
            if direction == 1:
                head[0] += 10
            elif direction == 0:
                head[0] -= 10
            elif direction == 2:
                head[1] += 10
            elif direction == 3:
                head[1] -= 10
            if head == bomb_position:
                bomb_position = [random.randint(1, int((disp_width - 10) / 10)) * 10,random.randint(1, int((disp_height - 10) / 10)) * 10]
                hit += 1
                body.insert(0,list(head))

            else:
                body.insert(0,list(head))
                body.remove((body[-1]))

            pygame.display.update()
            prev_direction = direction
            snake_head = body[0]
            if snake_head[0]>=disp_width or snake_head[0]<0 or snake_head[1]>=disp_height or snake_head[1]<0 or snake_head in body[1:]:
                dead = True
                
            fpsclock.tick(fps)
        return hit

    def main(width = 800, height = 600, grey = (100,100,100), black = (0,0,0)):
        run = True
        while run == True:
            global display, win_color,color,fpsclock, disp_height, disp_width, xll, yll,game_mode,fps
            #parameters 
            win_color, disp_width, disp_height = grey, width, height
            if level == "hard":
                fps = 45
            elif level == "easy":
                fps = 20
            game_mode = begin_game
            green = (0,128,0)
            color = [green, black]
            bomb_image = pygame.image.load('bomb.png')
            fpsclock=pygame.time.Clock() 
            xll = random.randrange(1, int((disp_width - 10) / 10)) * 10
            yll = random.randrange(1, int((disp_height - 10) / 10)) * 10
            head = [xll,yll]
            body = [[150,200],[140,200]]
            bomb_position = [xll, yll]
            hit = 0
    
            #game window
            display = pygame.display.set_mode((disp_width,disp_height))
            play_game(head, body, bomb_position, 1, bomb_image, hit)
            display.fill(grey)
            pygame.display.update()
            
            if dead == True:
                run = False
                dead_screen()


            pygame.quit()
    main()

def intro():
    background = pygame.image.load('bkv2.png')
    gameDisplay = pygame.display.set_mode((display_width, display_height))
    clock = pygame.time.Clock()
    while intro:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                
        gameDisplay.blit(background, (0, 0))

        button("Begin",150,450,100,50,green,bright_green,begin)
        button("Quit",550,450,100,50,red,bright_red, quit)
        button("Info",0,0,50,50,dull_white,white,info)
        pygame.display.update()
        clock.tick(15)

def quit():
    pygame.quit()
    quit()

def button(msg,x,y,w,h,ic,ac,action):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if x+w > mouse[0] > x and y+h > mouse[1] > y:
            pygame.draw.rect(gameDisplay, ac,(x,y,w,h))

            if click[0] == 1 and action != None:
                action()         
        else:
            pygame.draw.rect(gameDisplay, ic,(x,y,w,h))
        smallText = pygame.font.SysFont("stylus",20)

        textSurf= smallText.render(msg, True, black)
        textRect = textSurf.get_rect() #text_objects(msg, smallText)
        textRect.center = ( (x+(w/2)), (y+(h/2)) )
        gameDisplay.blit(textSurf, textRect)

def unpause():
    global pause
    pause = False

def paused():
    background = pygame.image.load('bkv2.png')
    gameDisplay = pygame.display.set_mode((display_width, display_height))
    clock = pygame.time.Clock()
    while pause:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                
        gameDisplay.fill(black)
        gameDisplay.blit(background, (100, 100))

        button("Menu",50,100,100,50,green,bright_green,intro)
        button("Resume",50,228,100,50,green,bright_green, unpause) 
        button("Restart",50,373,100,50,green,bright_green,game_mode)
        button("Quit",50,500,100,50,red,bright_red, quit)
        pygame.display.update()
        clock.tick(15)

    
def begin():
    #menu to choose what mode you want to select from
    background = pygame.image.load('bkv2.png')
    gameDisplay = pygame.display.set_mode((display_width, display_height))
    clock = pygame.time.Clock()
    while begin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                
        gameDisplay.fill(black)
        gameDisplay.blit(background, (100, 100))

        button("Menu",50,100,100,50,green,bright_green,intro)
        button("Easy",50,228,100,50,green,bright_green,easy_mode) 
        button("Hard",50,373,100,50,green,bright_green,hard_mode)
        button("Quit",50,500,100,50,red,bright_red, quit)
        pygame.display.update()
        clock.tick(15)
        
def dead_screen():
    background = pygame.image.load('bkv2.png')
    gameDisplay = pygame.display.set_mode((display_width, display_height))
    clock = pygame.time.Clock()
    while dead_screen:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                
        gameDisplay.fill(black)
        gameDisplay.blit(background, (100, 100))

        button("Menu",50,75,100,50,green,bright_green,intro)
        button("Restart",50,260,100,50,green,bright_green,game_mode)
        button("Quit",50,450,100,50,red,bright_red, quit)
        for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        game_mode()
        pygame.display.update()
        clock.tick(45)


def info():
    x,y = -100,-300
    background = pygame.image.load('infov3.png')
    gameDisplay = pygame.display.set_mode((display_width, display_height))
    clock = pygame.time.Clock()
    #menu to tell features
    while info:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        gameDisplay.fill(black)
        gameDisplay.blit(background, (x,y))
        for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        if y != -300:
                            y += 200
                    if event.key == pygame.K_DOWN:
                        if y != -1500:
                            y -= 200
        if y == -1500:
            button("Menu",325,535,100,50,green,bright_green,intro)
        pygame.display.update()
        clock.tick(1000)

def multiplayer(): #attempt to make multiplayer that failed
    ...

intro()


